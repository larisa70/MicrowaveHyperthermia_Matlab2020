clear all
close all
clc

%% Read the necessary data
S0 = load('S_Matrix_16Monopole_BaseLine.mat');          %Prob data for the baseline scenario
FieldNameA = fieldnames(S0);
SBaseLine = getfield(S0,FieldNameA{1});

SSeries = load('S_Matrix_16Monopole_TimeSeries.mat');   %Prob data set for time steps  
FieldNameB = fieldnames(SSeries);
STimeSeries = getfield(SSeries,FieldNameB{1});

PreComputed = load('M_16Ant_40x42x26GeoMatrix_Resolution2mm_SVD_Economy.mat');    %Precomputed solution from M-calculation
FieldName = fieldnames(PreComputed);
M = getfield(PreComputed,FieldName{1});

Geometrics = load('../M_Calculation/EfielsPlusSMatrix_Baseline/Geo_04_Monopole16_for_Tomography_Baseline_t0_temp55degc_LowerContrast2MatchingFluid.mat'); %A struct containing {Geo, XX, YY, ZZ}
Geo = Geometrics.Geo;
X = Geometrics.XX;
Y = Geometrics.YY;
Z = Geometrics.ZZ;

NumAnt = size(SBaseLine,1);
NumTSteps = size(STimeSeries,3);

%% Differential input for temporal steps
DeltaS = STimeSeries - repmat(SBaseLine,[1 1 NumTSteps]);       %To be fed as 'd' to the algorithm
[XM, YM, ZM] = meshgrid(X, Y, Z);
Xcenter = 0.02;     %To draw a dashed line over the target area
Ycenter = -0.01;    %To draw a dashed line over the target area
%***************************************************************************************************


% read file with transposed Kernel

KernelT = load('KernelT.mat');  
FieldNameK = fieldnames(KernelT);
KernelT = getfield(KernelT,FieldNameK{1});


    
%***************************************************************************************************
%% Conversion
DeltaOs = cell(1,NumTSteps);
for tn = 1:NumTSteps
    d = reshape(DeltaS(:,:,tn),NumAnt^2,1);
    mTildaArray = M*d;

%*************************************************************************************************
    
  %   compute rhs= A'*d for least squares formulation to be able to use it in petsc 
  %LSrhs(:,tn) = (gather(Kernel)')*d;
  LSrhs(:,tn) = (gather(KernelT))*d;
    % save rhs to use in petsc
    drhs(:,tn) = d;

%**************************************************************************************************
    mTilda = reshape(abs(mTildaArray),size(Geo));
    DeltaOs{1,tn} = mTilda;
    figure
    slice(XM,YM,ZM,DeltaOs{1,tn},X(36),Y(21),Z(7));
    colormap jet
    caxis([0 0.8e-7])
    colorbar
    axis image
    xlabel('x (m)')
    ylabel('y (m)')
    zlabel('z (m)')
    shading interp
    title(['t = ' num2str(tn) 'min'])
    figure(10)
    subplot(2,3,tn)
    pcolor(X,Y,mTilda(:,:,7))
    shading interp
    colormap jet
    caxis([0 0.8e-7])
    colorbar
    hold on
    h = ezplot(@(x,y) (x-Xcenter).^2+(y-Ycenter).^2 - 0.015^2,[min(X), max(X), min(Y), max(Y)]);
    set(h,'color','k','LineStyle','--','LineWidth',1.5)
    hold off
    title(['t = ' num2str(tn) 'min'])
end


    
% save files for C++/PETSc computations
%save('LSrhs.mat','LSrhs');

save('drhs.mat','drhs');

%  print out file for FEM computations

fid = fopen('realSolFEM.dat','wt');
fprintf(fid,'%hd\n',real(mTildaArray));
fclose(fid);

fid = fopen('imagSolFEM.dat','wt');
fprintf(fid,'%hd\n',imag(mTildaArray));
fclose(fid);

% save A^T*d
fid = fopen('realAtd.dat','wt');
fprintf(fid,'%hd\n',real(LSrhs(:,tn)));
fclose(fid);

fid = fopen('imagAtd.dat','wt');
fprintf(fid,'%hd\n',imag(LSrhs(:,tn)));
fclose(fid);

%  size of the 3D mesh for Paper 1
nx = 40; %  n_x
ny = 42; %  n_y
nz = 26; %  n_z


sch = 0;
schxy =0;
schxz = 0;
  
 %for i=1:nx
  for k= 1:nz
     for j=1:ny
          for i=1:nx
      sch = sch  +1;
  
 % to save geometry data which we want  to use in FEM computations 
 
     ObjectFEM3D(sch) = Geo(i+nx*((j-1) + ny*(k-1)));
     
     % if we want save slices

     %if (k == TR_z)
     %     schxy = schxy  +1;
     %    sliceXY(schxy) = Geo(i+nx*((j-1) + ny*(k-1)));
     %    mTildaXY(schxy) = mTilda(i+nx*((j-1) + ny*(k-1)));          
     %end
     
    %  if (j == TR_y)
    %       schxz = schxz  +1;
    %     sliceXZ(schxz) = Geo(i+nx*((j-1) + ny*(k-1)));
    %     mTildaXZ(schxz) = mTilda(i+nx*((j-1) + ny*(k-1)));
    % end
     
         end
     end
 end
     
        
 
         
	 fid = fopen('GeoFEM.dat','wt');
fprintf(fid,'%hd\n',ObjectFEM3D);
fclose(fid);
      

%fid = fopen('SliceXY.dat','wt');
%fprintf(fid,'%hd\n',sliceXY);
%fclose(fid);

% fid = fopen('SliceXZ.dat','wt');
%fprintf(fid,'%hd\n',sliceXZ);
%fclose(fid);


% fid = fopen('mTildaXY.dat','wt');
%fprintf(fid,'%hd\n',mTildaXY);
%fclose(fid);

% fid = fopen('mTildaXZ.dat','wt');
%fprintf(fid,'%hd\n',mTildaXZ);
%fclose(fid);
